import sys, os
extensions = ['sphinx.ext.autodoc', 'sphinx.ext.doctest', 'sphinx.ext.mathjax']
templates_path = ['_templates']
source_suffix = '.rst'
master_doc = 'TEST_GEMBS'
project = u'Bisulfite Pipeline'
exclude_patterns = []
pygments_style = 'sphinx'
import sphinx_rtd_theme
html_theme = "sphinx_rtd_theme"
html_theme_path = [sphinx_rtd_theme.get_html_theme_path()]
html_static_path = ['_static']
htmlhelp_basename = 'BISULFITEPIPELINEdoc'
#Latex Elements
latex_elements = {
# The paper size ('letterpaper' or 'a4paper').
#'papersize': 'letterpaper',
# The font size ('10pt', '11pt' or '12pt').
'pointsize': '10pt',
# Additional stuff for the LaTeX preamble.
#'preamble': '',
'classoptions': ',oneside',
'babel': '\usepackage[english]{babel}',
'releasename':'TEST\_GEMBS'
}
latex_documents = [
('TEST_GEMBS', 'TEST_GEMBS.bisulfite.tex', u'BISULFITE PIPELINE',
u'gemBS', 'manual'),
]
